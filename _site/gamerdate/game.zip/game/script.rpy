﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define config.nearest_neighbor = True

define pony = Character("PONY", color="#00CCCC", what_color="#00CCCC")
define ruby = Character("RUBY", color="#BC42BC", what_color="#BC42BC")
define iris = Character("IRIS", color="#00E8E8", what_color="#00E8E8")
define beau = Character("BEAU", color="#CCCC00", what_color="#CCCC00")

transform midleft:
 xalign 0.3
 yalign 1.0

transform midright:
 xalign 0.7
 yalign 1.0

transform flip:
 xzoom -1.0

# The game starts here.

label start:

 scene bg teashop
 with fade

 play music "audio/troubled teatime.mp3"

 show pony smile mild at midleft
 show ruby neutral at midright, flip
 with dissolve

 pony "Is he actually just named WOLF KNIGHT?"

 ruby "i think so yeh"
 
 show pony embarrassed at midleft
 
 pony "That's so weird. I call my dad Wolf Dad."
 
 ruby "aw"
 
 show pony smile mild at midleft
 
 pony "But he's just like a normal human business guy."
 
 show ruby happy at midright, flip
 
 ruby "a career boy"
 
 stop music fadeout 1.0
 
 scene bg black
 with fade
 
 "Later..."
 
 play music "audio/at rubys place.mp3"
 
 scene bg fire escape
 with fade
 
 show pony neutral at midright, flip
 show ruby neutral at midleft
 with dissolve
 
 pony "Hey, when you deal with this evil overlord President guy tomorrow, I want to help."
 
 show ruby happy
 
 ruby "thats my maven"
 
 ruby "were getting the band back together"
 
 show ruby neutral
 show pony smile mild
 
 pony "What's our band name?"
 
 pony "What about"
 
 show pony happy
 
 pony "Glitch Busters!"
 
 show pony smile mild
 show ruby neutral
 
 ruby "no"
 ruby "check the groupchat where we came up with like 79 or 89 of them"
 
 pony "The Pre-Socratics"
 
 ruby "not that one"
 
 pony "Mask of the Other"
 
 show ruby incredulous
 
 ruby "take it again"
 
 pony "Slander"
 
 show ruby neutral
 
 ruby "slanders pretty good"
 
 show pony neutral
 
 pony "That one was Ambassador's iirc"
 
 show ruby concerned
 
 ruby "yeh"
 ruby "hey will ze be okay w you coming w me tomorrow"
 ruby "it sounded like you two were in the middle of something"
 
 pony "Ze'll be fine. Ze's tough."
 
 ruby "cool just checkin"
 ruby "i just mean i get that ya'll are still close"
 
 pony "I like Ambassador a lot but"
 pony "I'm not zir sidekick."
 pony "Or zir pawn."
 
 scene bg black
 with fade
 
 "Ruby climbs back through her window. With Pony leaning on the windowsill - Ruby advises him not to come inside."
 "They make plans for crashing the President's Gala tomorrow."
 
 scene bg fire escape
 with fade
 
 show pony smile mild at midright, flip
 show ruby neutral at midleft
 with dissolve 
 
 ruby "ill figure out a way to get you in"
 ruby "manufact a duplicate calling card or smth"
 ruby "but even with the invite we all need to dress sharp"
 ruby "and maven angel they wont let you through the door in that sweater"
 
 show pony neutral
 
 pony "haha..."
 pony "Do you have any cool Chenoweth outfits you can lend me?"
 
 ruby "nah srry im gonna make my own custom look"
 ruby "none of the masc clothes i have lying around would fit you anyway"
 
 stop music fadeout 3.0
 
 ruby "lanky boy"
 ruby "unless you wanna wear a dress lmao"
 
 show pony embarrassed
 
 pony ". . ."
 pony ". . . . . ."
 
 "no good, this thing's going up in flames."
 
 show ruby concerned
 
 ruby "hello"
 ruby "you good maven"
 
 pony "i um"
 pony "i."
 pony "i want to but"
 
 show pony sad
 
 pony "i'm worried it wouldn't look right on me?"
 
 play music "audio/lanterns and mirrors.mp3"
 
 ruby "whats wrong with my dresses"
 ruby "oh"
 ruby "ohhhhhh"
 ruby "ohhh oh oh wait okay okay wait"
 
 pony "sorry"
 
 ruby "no no maven you are so good"
 ruby "youre super good"
 
 pony "But if you don't have any anyway"
 
 ruby "you can absolutely borrow one of mine"
 ruby "i would just need to adjust my balls in the air a little"
 
 pony "And I'm like a scarecrow clown man it wouldn't even fit"
 
 ruby "maven sweetheart please stop hyperventilating while im scheming"
 ruby "the world is literally ending tmrw if we dont stop it"
 
 show ruby neutral
 
 ruby "plus its an art school party"
 
 show ruby happy
 
 ruby "if there was any day to wear whatever the f>ck you want its this"
 
 "THE END (for now)"
 
return
